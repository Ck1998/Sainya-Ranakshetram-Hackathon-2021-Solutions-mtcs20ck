Short readme on Vulnerable PHP challenge


Vulnerabilities - 
1. Stored XSS
2. SQLi


The main directory contains two folders -
1. original_code - This directory contains the original code that was given as part of the challenge and it extracted from the rar file.
2. modified_and_secure_code - This directory contains modified index.php and profile.php  which have been made invulnearble to XSS and SQLi. 